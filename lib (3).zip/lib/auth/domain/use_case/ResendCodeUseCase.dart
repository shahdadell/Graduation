import 'package:graduation_project/auth/data/model/response/ResendCode.dart';
import 'package:graduation_project/auth/domain/repository/repository/auth_repository_contract.dart';

class ResendCodeUseCase {
  AuthRepositoryContract repositoryContract;

  ResendCodeUseCase({required this.repositoryContract});

  Future<ResendCode> invoke(String email) async {
    return await repositoryContract.resendCode(email);
  }
}